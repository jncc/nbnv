<html>
<head>
</head>
<body>
<?php 	print(date("d-F-Y H:i:s")); ?>

<form action="http://localhost/nbn/TaxonomySearch.php" method="post">
	<p>Enter search term: <input type="text" name="term" /></p>
	<p><input type="submit" /></p>
</form>

<?php 
	error_reporting(1);

	require_once('../lib/nusoap.php');

	$client = new soapclient('http://www.nbnws.net/ws_3_5/GatewayWebService?wsdl',true);

	if($client->fault){
		echo "FAULT:  <p>Code: {$client->faultcode} >br />";
		echo "String: {$client->faultstring} </p>";
	}
	
	//Get the search term
	$term = (is_null($_POST['term']) ? '' : $_POST['term']);
	
	$taxonomySearchQuery = 
	'<tax:TaxonomySearchRequest registrationKey="a85d4c129728e58da6ed1b9af84632e15e2b5927"
		xmlns:tax="http://www.nbnws.net/Taxon/Taxonomy"
		xmlns:tax1="http://www.nbnws.net/Taxon">
			<tax:SearchTerm>' . $term . '</tax:SearchTerm>
      </tax:TaxonomySearchRequest>';

	$response = $client->call('GetTaxonomySearch', $taxonomySearchQuery);
	
	$nothingFound = ($response['Taxa'] == '');

	if($nothingFound){
		print '<p>Nothing found, please try again</p>';
	}else{
		print '<table><tr><th>Name</th><th>Authority</th><th>Taxon version key</th>';
		if (isset($response['Taxa']['Taxon'][0])) {
			foreach($response['Taxa']['Taxon'] as $taxon){
				print '<tr><td>' . $taxon['TaxonName']['!'] . '</td><td>' . $taxon['Authority'] . '</td><td>' . $taxon['TaxonVersionKey'] . '</td></tr>';
			}
		}else{
			$taxon = $response['Taxa']['Taxon'];
			print '<tr><td>' . $taxon['TaxonName']['!'] . '</td><td>' . $taxon['Authority'] . '</td><td>' . $taxon['TaxonVersionKey'] . '</td></tr>';
		}
		print '</table>';
	}
?>

<?php
	$showXML = false;
	if($showXML){
		echo '<h2>Request</h2>';
		echo '<pre>' . htmlspecialchars($client->request, ENT_QUOTES) . '</pre>';
		echo '<h2>Response</h2>';
		echo '<pre>' . htmlspecialchars($client->response, ENT_QUOTES) . '</pre>';
	}
?>

</body>
</html>