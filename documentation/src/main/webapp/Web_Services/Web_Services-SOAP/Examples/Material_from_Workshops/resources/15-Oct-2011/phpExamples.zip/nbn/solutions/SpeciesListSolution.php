<html>
<head>
</head>
<body>

<?php 
print(date("d-F-Y H:i:s"));
error_reporting(0);

	require_once('../lib/nusoap.php');
	
	$client = new soapclient('http://www.nbnws.net/ws_3_5/GatewayWebService?wsdl',true);

	if($client->fault){
		echo "FAULT:  <p>Code: {$client->faultcode} >br />";
		echo "String: {$client->faultstring} </p>";
	}

	//Paste your edited species list request from soapUI
	$speciesListQuery = 
	'<tax:SpeciesListRequest registrationKey="a85d4c129728e58da6ed1b9af84632e15e2b5927"
		xmlns:tax="http://www.nbnws.net/Taxon" 
		xmlns:spat="http://www.nbnws.net/Spatial" 
		xmlns:sit="http://www.nbnws.net/SiteBoundary" 
		xmlns:map="http://www.nbnws.net/Map" 
		xmlns:dat="http://www.nbnws.net/Dataset" 
		xmlns:tax1="http://www.nbnws.net/TaxonReportingCategory">
         <dat:DatasetList>
            <dat:DatasetKey>GA000012</dat:DatasetKey>
         </dat:DatasetList>
      </tax:SpeciesListRequest>
	';

	//Add the name of the web service (see list of web services in soapUI navigator)
	$response = $client->call('GetSpeciesList', $speciesListQuery);

	//Extract the information from the response that we need for our web page
	//See http://www.nbn.org.uk/Guidebooks/Web-services-documentation/the-web-services/Species-List/response.aspx for info. on how the response is structured
	$SpeciesList = $response['SpeciesList'];
	$DatasetTitle = $resonse['DatasetSummaryList']['DatasetSummary']['ProviderMetadata']['DatasetTitle'];
?>

<!--Add a heading to the page, naming the dataset this species list is from-->
<h1>Species list for dataset: <?php print $DatasetTitle ?></h1>

<!--Iterate through the species list and display their scientific name-->
<ul>
<?php
foreach($SpeciesList['Species'] as $Species){
	print '<li>' . $Species['ScientificName'] . '</li>';
}
?>
</ul>

<?php
	//j. Display the XML of the request and response if you like
	$showXML = false;
	if($showXML){
		echo '<h2>Request</h2>';
		echo '<pre>' . htmlspecialchars($client->request, ENT_QUOTES) . '</pre>';
		echo '<h2>Response</h2>';
		echo '<pre>' . htmlspecialchars($client->response, ENT_QUOTES) . '</pre>';
	}
?>

</body>
</html>