<html>
<head>
</head>
<body>

<?php 
	print(date("d-F-Y H:i:s"));
	error_reporting(1);

	//a. Import the nusoap library 

	//b. Create the client to the gateway web services

	//c. SOAP fault handling

	//d. Create the request

	//e. Send the request and get the response


	//f. Extract the information from the response that we need for our web page
	//See http://www.nbn.org.uk/Guidebooks/Web-services-documentation/the-web-services/Grid-map/response.aspx for info. on how the response is structured
?>

<!--g. Print title and map image with copyright.
Note: the copyright text can be found in the Terms and Conditions retrieved either 
from the response or from http://data.nbn.org.uk/help/popups/generalTerms.jsp-->
<h1>Grid map for <i>???</i></h1>
<div>
Image ???
<p>&copy; ???</p>
</div>

<!--h. Acknowledge the dataset providers-->
<table>
<tr><th>Provider</th><th>Dataset title</th></tr>
<?php 
?>
</table>

<!--i.  Add the NBN logo and Terms and Conditions-->

<?php
	//j.  Display the XML of the request and response if you like
?>

</body>
</html>