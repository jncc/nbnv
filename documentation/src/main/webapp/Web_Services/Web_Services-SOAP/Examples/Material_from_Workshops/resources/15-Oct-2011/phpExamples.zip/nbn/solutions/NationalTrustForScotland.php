<html><head></head><body>
<?php 
	print(date("d-F-Y H:i:s"));
	error_reporting(1);

	require_once('../lib/nusoap.php');

	$client = new soapclient('http://www.nbnws.net/ws_3_5/GatewayWebService?wsdl',true);
	
	if($client->fault){
		echo "FAULT:  <p>Code: {$client->faultcode} >br />";
		echo "String: {$client->faultstring} </p>";
	}
	
	//Get the site (property), if none is provided give it a default
	$SiteKey = (is_null($_GET['SiteKey']) ? 'BAL' : $_GET['SiteKey']);
	$SiteName = (is_null($_GET['SiteName']) ? 'Balmacara Estate & Lochalsh Woodland Garden' : $_GET['SiteName']);

	//Get the species list for the property
	//Will want to consider what resolution records needed, whether overlapping or contained by the property and whether to limit to specific species datasets
	$SpeciesListQuery = 
      '<tax:SpeciesListRequest registrationKey="a85d4c129728e58da6ed1b9af84632e15e2b5927" xmlns:tax="http://www.nbnws.net/Taxon" xmlns:spat="http://www.nbnws.net/Spatial" xmlns:sit="http://www.nbnws.net/SiteBoundary" xmlns:map="http://www.nbnws.net/Map" xmlns:dat="http://www.nbnws.net/Dataset" xmlns:tax1="http://www.nbnws.net/TaxonReportingCategory">
         <spat:GeographicalFilter>
            <sit:SiteBoundary siteKey="' . $SiteKey . '" providerKey="GA000505">
            </sit:SiteBoundary>
            <map:MapSettings height="400" width="400" outlineWidth="1" outlineColour="#000000" fillColour="#0000ff" fillTransparency="0.5" mapOnly="false"/>
            <spat:OverlayRule>?overlaps</spat:OverlayRule>
            <spat:MinimumResolution>_100m</spat:MinimumResolution>
         </spat:GeographicalFilter>
      </tax:SpeciesListRequest>';

	$SpeciesListResponse = $client->call('GetSpeciesList', $SpeciesListQuery);
	
	//Get the data we need
	$Map = $SpeciesListResponse['Map'];
	$MapUrl = $Map['Url'];
	$SpeciesList = $SpeciesListResponse['SpeciesList'];
	$DatasetSummaryList = $SpeciesListResponse['DatasetSummaryList'];
	$NBNLogo = $SpeciesListResponse['!NBNLogo'];
	$TermsAndConditions = $SpeciesListResponse['!TermsAndConditions'];

	//Do the site (property) list query
	$SiteListQuery = 
	'<sit:SiteBoundaryListRequest registrationKey="a85d4c129728e58da6ed1b9af84632e15e2b5927" xmlns:sit="http://www.nbnws.net/SiteBoundary">
        <sit:SiteBoundaryType>NTS</sit:SiteBoundaryType>
    </sit:SiteBoundaryListRequest>';
	  
	$SiteListResponse = $client->call('GetSiteBoundaryList', $SiteListQuery);
	
	$SiteBoundaryList = $SiteListResponse['SiteBoundaryList'];
?>

<h1>Property map and species list for <?php print $SiteName; ?></h1>
<table><th>Map</th><th>Species List</th><th>Datasets</th></tr>
<tr><td valign="top" align="middle">
	<div>
		<img src="<?php print $MapUrl; ?>" />
		<p>&copy; Crown copyright and database rights 2011 Ordnance Survey [100017955]</p>
	</div>
</td>
<td valign="top" align="middle">
	<ul>
	<?php
	foreach($SpeciesList['Species'] as $Species){
		print '<li><a href="/nbn/GridMapSpeciesList.php?taxonkey=' . $Species['!taxonVersionKey'] . '">' . $Species['ScientificName'] . '</a></li>';
	}
	?>
	</ul>
</td>
<td valign="top" align="middle">
	<table border="1">
	<tr><th>Provider</th><th>Dataset title</th></tr>
	<?php 
		if (isset($DatasetSummaryList['DatasetSummary'][0])) {
			foreach ($DatasetSummaryList['DatasetSummary'] as $DatasetSummary) {
				$ProviderMetadata = $DatasetSummary['ProviderMetadata'];
				print '<tr><td>'.$ProviderMetadata['DatasetProvider'].'</td>';
				print '<td>'.$ProviderMetadata['DatasetTitle'].'</td></tr>';
			}
		} else {
			$DatasetSummary = $DatasetSummaryList['DatasetSummary'];
			$ProviderMetadata = $DatasetSummary['ProviderMetadata'];
			print '<tr><td>'.$ProviderMetadata['DatasetProvider'].'</td>';
			print '<td>'.$ProviderMetadata['DatasetTitle'].'</td></tr>';
		}
	?>
	</table>
</td></tr></table>
<hr>
<h2>Choose another property</h2>
<?php
foreach($SiteBoundaryList['SiteBoundary'] as $SiteBoundary){
	print '<li><a href="/nbn/NationalTrustForScotland.php?SiteKey=' . $SiteBoundary['!siteKey'] . '&SiteName=' . $SiteBoundary['SiteBoundaryName'] . '">' . $SiteBoundary['SiteBoundaryName'] . '</a></li>';
}
?>
</ul>

<p><a href="http://data.nbn.org.uk"><img src="<?php print $NBNLogo ?>"/></a></p>
<p><a href="<?php print $TermsAndConditions ?>">Terms and conditions</a></p>
</body></html>
