<html>
<head>
</head>
<body>

<?php 
print(date("d-F-Y H:i:s"));
error_reporting(0);

	//a. Import the nusoap library 
	require_once('../lib/nusoap.php');
	
	//b. Create the client to the gateway web services
	$client = new soapclient('http://www.nbnws.net/ws_3_5/GatewayWebService?wsdl',true);

	//c. SOAP fault handling
	if($client->fault){
		echo "FAULT:  <p>Code: {$client->faultcode} >br />";
		echo "String: {$client->faultstring} </p>";
	}

	//d. Create the request
	$gridMapQuery = 
	'<map:GridMapRequest registrationKey="a85d4c129728e58da6ed1b9af84632e15e2b5927"  
		xmlns:map="http://www.nbnws.net/Map" 
		xmlns:tax="http://www.nbnws.net/Taxon" 
		xmlns:dat="http://www.nbnws.net/Dataset" 
		xmlns:spat="http://www.nbnws.net/Spatial" 
		xmlns:sit="http://www.nbnws.net/SiteBoundary">
			<tax:TaxonVersionKey>NBNSYS0000005629</tax:TaxonVersionKey>
	</map:GridMapRequest>';

	//e. Send the request and get the response
	$response = $client->call('GetGridMap', $gridMapQuery);

	//f. Extract the information from the response that we need for our web page
	//See http://www.nbn.org.uk/Guidebooks/Web-services-documentation/the-web-services/Grid-map/response.aspx for info. on how the response is structured

	//Map url
	$Map = $response['Map'];
	$MapUrl = $Map['Url'];

	//Species name
	$Species = $response['Species'];
	$SpeciesName = $Species['ScientificName'];

	//List of datasets contributing to the map
	$DatasetSummaryList = $response['DatasetSummaryList'];

	//The NBN logo and terms and conditions
	//Note: attributes of xml elements are represented in php with a leading exclamation mark
	$NBNLogo = $response['!NBNLogo'];
	$TermsAndConditions = $response['!TermsAndConditions'];
?>

<!--g. Print title and map image with copyright.
Note: the copyright text can be found in the Terms and Conditions retrieved either 
from the response or from http://data.nbn.org.uk/help/popups/generalTerms.jsp-->
<h1>Grid map for <i><?php print $SpeciesName; ?></i></h1>
<div>
	<img src="<?php print $MapUrl; ?>" />
	<p>&copy; Crown copyright and database rights 2011 Ordnance Survey [100017955]</p>
</div>

<!--h. Acknowledge the dataset providers-->
<table>
<tr><th>Provider</th><th>Dataset title</th></tr>
<?php 
	//Note: if multiple DatasetSummary elements are returned they will be presented 
	//as an array.  This needs handling differently from when just one 
	//DatasetSummary is returned, which won't be in an array.
	if (isset($DatasetSummaryList['DatasetSummary'][0])) {
		foreach ($DatasetSummaryList['DatasetSummary'] as $DatasetSummary) {
			$ProviderMetadata = $DatasetSummary['ProviderMetadata'];
			print '<tr><td>'.$ProviderMetadata['DatasetProvider'].'</td>';
			print '<td>'.$ProviderMetadata['DatasetTitle'].'</td></tr>';
		}
	} else {
		$DatasetSummary = $DatasetSummaryList['DatasetSummary'];
		$ProviderMetadata = $DatasetSummary['ProviderMetadata'];
		print '<tr><td>'.$ProviderMetadata['DatasetProvider'].'</td>';
		print '<td>'.$ProviderMetadata['DatasetTitle'].'</td></tr>';
	}
?>
</table>

<!--i. Add the NBN logo and Terms and Conditions-->
<p><a href="http://data.nbn.org.uk"><img src="<?php print $NBNLogo ?>"/></a></p>
<p><a href="<?php print $TermsAndConditions ?>">Terms and conditions</a></p>

<?php
	//j. Display the XML of the request and response if you like
	$showXML = false;
	if($showXML){
		echo '<h2>Request</h2>';
		echo '<pre>' . htmlspecialchars($client->request, ENT_QUOTES) . '</pre>';
		echo '<h2>Response</h2>';
		echo '<pre>' . htmlspecialchars($client->response, ENT_QUOTES) . '</pre>';
	}
?>

</body>
</html>