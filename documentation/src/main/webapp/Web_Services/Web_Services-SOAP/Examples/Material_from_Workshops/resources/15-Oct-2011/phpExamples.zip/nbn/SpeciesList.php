<html>
<head>
</head>
<body>

<?php 
print(date("d-F-Y H:i:s"));
error_reporting(0);

	require_once('../lib/nusoap.php');
	
	$client = new soapclient('http://www.nbnws.net/ws_3_5/GatewayWebService?wsdl',true);

	if($client->fault){
		echo "FAULT:  <p>Code: {$client->faultcode} >br />";
		echo "String: {$client->faultstring} </p>";
	}

	//Paste your edited species list request from soapUI
	$speciesListQuery = '';

	//Add the name of the web service (see list of web services in soapUI navigator)
	$response = $client->call('Add web service name here', $speciesListQuery);

	//Extract the information from the response that we need for our web page
	//See http://www.nbn.org.uk/Guidebooks/Web-services-documentation/the-web-services/Species-List/response.aspx for info. on how the response is structured
?>

<!--Add a heading to the page, naming the dataset this species list is from-->
<h1>Species list for dataset: ???</h1>

<!--Iterate through the species list and display their scientific name-->
<ul>
Add species scientific name here
</ul>

<?php
	//j. Display the XML of the request and response if you like
	$showXML = false;
	if($showXML){
		echo '<h2>Request</h2>';
		echo '<pre>' . htmlspecialchars($client->request, ENT_QUOTES) . '</pre>';
		echo '<h2>Response</h2>';
		echo '<pre>' . htmlspecialchars($client->response, ENT_QUOTES) . '</pre>';
	}
?>

</body>
</html>