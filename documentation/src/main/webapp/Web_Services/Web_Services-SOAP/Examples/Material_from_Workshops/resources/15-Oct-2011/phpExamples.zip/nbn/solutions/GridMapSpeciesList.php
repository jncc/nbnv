<html>
<head>
</head>
<body>

<?php 
	print(date("d-F-Y H:i:s"));
	error_reporting(1);

	require_once('../lib/nusoap.php');

	$client = new soapclient('http://www.nbnws.net/ws_3_5/GatewayWebService?wsdl',true);
	
	if($client->fault){
		echo "FAULT:  <p>Code: {$client->faultcode} >br />";
		echo "String: {$client->faultstring} </p>";
	}
	
	//Get the species key, if there isn't one then default to the Norfolk Hawker (NBNSYS0000005629)
	$taxonkey = (is_null($_GET['taxonkey']) ? 'NBNSYS0000005629' : $_GET['taxonkey']);

	//Do the grid map
	$gridMapQuery = 
	'<map:GridMapRequest registrationKey="a85d4c129728e58da6ed1b9af84632e15e2b5927"
		xmlns:map="http://www.nbnws.net/Map" 
		xmlns:tax="http://www.nbnws.net/Taxon" 
		xmlns:dat="http://www.nbnws.net/Dataset" 
		xmlns:spat="http://www.nbnws.net/Spatial" 
		xmlns:sit="http://www.nbnws.net/SiteBoundary">
			<tax:TaxonVersionKey>' . $taxonkey . '</tax:TaxonVersionKey>
         <dat:DatasetList>
            <dat:DatasetKey>GA000012</dat:DatasetKey>
         </dat:DatasetList>
	</map:GridMapRequest>';
	$gridMapResponse = $client->call('GetGridMap', $gridMapQuery);
	$Map = $gridMapResponse['Map'];
	$MapUrl = $Map['Url'];
	$Species = $gridMapResponse['Species'];
	$SpeciesName = $Species['ScientificName'];
	$DatasetSummaryList = $gridMapResponse['DatasetSummaryList'];
	$NBNLogo = $gridMapResponse['!NBNLogo'];
	$TermsAndConditions = $gridMapResponse['!TermsAndConditions'];

	//Do the species list query
		$speciesListQuery = 
	'<tax:SpeciesListRequest
		registrationKey="a85d4c129728e58da6ed1b9af84632e15e2b5927"
		xmlns:tax="http://www.nbnws.net/Taxon" 
		xmlns:spat="http://www.nbnws.net/Spatial" 
		xmlns:sit="http://www.nbnws.net/SiteBoundary" 
		xmlns:map="http://www.nbnws.net/Map" 
		xmlns:dat="http://www.nbnws.net/Dataset" 
		xmlns:tax1="http://www.nbnws.net/TaxonReportingCategory">
         <dat:DatasetList>
            <dat:DatasetKey>GA000012</dat:DatasetKey>
         </dat:DatasetList>
      </tax:SpeciesListRequest>
	';
	$speciesListResponse = $client->call('GetSpeciesList', $speciesListQuery);
	$SpeciesList = $speciesListResponse['SpeciesList'];
	$DatasetTitle = $speciesListResponse['DatasetSummaryList']['DatasetSummary']['ProviderMetadata']['DatasetTitle'];

?>

<h1>Grid map for <i><?php print $SpeciesName; ?></i></h1>
<div>
	<img src="<?php print $MapUrl; ?>" />
	<p>&copy; Crown copyright and database rights 2011 Ordnance Survey [100017955]</p>
</div>

<ul>
<?php
foreach($SpeciesList['Species'] as $Species){
	print '<li><a href="/nbn/GridMapSpeciesList.php?taxonkey=' . $Species['!taxonVersionKey'] . '">' . $Species['ScientificName'] . '</a></li>';
}
?>

<table>
<tr><th>Provider</th><th>Dataset title</th></tr>
<?php 
	if (isset($DatasetSummaryList['DatasetSummary'][0])) {
		foreach ($DatasetSummaryList['DatasetSummary'] as $DatasetSummary) {
			$ProviderMetadata = $DatasetSummary['ProviderMetadata'];
			print '<tr><td>'.$ProviderMetadata['DatasetProvider'].'</td>';
			print '<td>'.$ProviderMetadata['DatasetTitle'].'</td></tr>';
		}
	} else {
		$DatasetSummary = $DatasetSummaryList['DatasetSummary'];
		$ProviderMetadata = $DatasetSummary['ProviderMetadata'];
		print '<tr><td>'.$ProviderMetadata['DatasetProvider'].'</td>';
		print '<td>'.$ProviderMetadata['DatasetTitle'].'</td></tr>';
	}
?>
</table>

<p><a href="http://data.nbn.org.uk"><img src="<?php print $NBNLogo ?>"/></a></p>
<p><a href="<?php print $TermsAndConditions ?>">Terms and conditions</a></p>

</body>
</html>